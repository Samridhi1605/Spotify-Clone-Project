# Spotify Clone 🎧

This is a simple frontend clone of Spotify using HTML, CSS, and JavaScript.

## Features:
- Click to play songs
- Responsive UI with song covers and titles

## How to run:
1. Download the folder
2. Open `index.html` in your browser
